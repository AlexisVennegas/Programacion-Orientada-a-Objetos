package com.proyecto.common;

public class Constantes {
	//Paso 1. Constante de cadena int "TAMANIO_MAX" con valor 25
	
	//Paso 2. Constante de cadena int "TAMANIO_MIN" con valor 2
	
	
 
}
