package com.proyecto.common;

public enum NotAllowedWord {DROP,TRUNCATE,DELETE,SELECT,INSERT,UPDATE;

}
