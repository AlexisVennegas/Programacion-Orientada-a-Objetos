package com.gesres.bussiness.interfaces;

import com.gesres.data.Plato;

public interface GestionPlatos {
	
	public void servirPlato(Plato plato);
	public int getNumeroPlatos(Plato plato);

}
