package com.gesres.common;

public class Ingredientes {

	public static final String HUEVOS = "HUEVOS";

	public static final String CHORIZO = "CHORIZO";
	
	public static final int DOCENAS = 12;

	public static final int KG = 1000;
}
