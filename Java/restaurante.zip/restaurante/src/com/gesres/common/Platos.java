package com.gesres.common;

public class Platos {

	public static final String HUEVOS_CON_CHORIZO = "Huevos con Chorizo";

}
