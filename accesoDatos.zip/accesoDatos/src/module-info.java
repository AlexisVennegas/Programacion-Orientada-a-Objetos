/**
 * 
 */
/**
 * 
 */
module accesoDatos {
	requires java.sql;
	requires log4j;
}